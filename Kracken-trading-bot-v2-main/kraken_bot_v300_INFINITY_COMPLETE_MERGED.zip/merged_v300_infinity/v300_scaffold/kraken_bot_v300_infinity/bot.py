# v300 scaffold bot entry
print('v300 scaffold running')