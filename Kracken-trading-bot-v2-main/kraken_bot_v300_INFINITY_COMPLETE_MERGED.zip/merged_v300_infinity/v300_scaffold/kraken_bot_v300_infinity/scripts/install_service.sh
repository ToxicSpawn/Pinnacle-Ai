#!/bin/bash
echo 'install scaffold'
